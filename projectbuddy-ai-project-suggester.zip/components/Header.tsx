
import React, { useState } from 'react';
import { Page } from '../types';

interface HeaderProps {
    onNavigate: (page: Page) => void;
    currentPage: Page;
}

const NavLink: React.FC<{ page: Page; label: string; onNavigate: (page: Page) => void; currentPage: Page; isMobile?: boolean; isButton?: boolean }> = ({ page, label, onNavigate, currentPage, isMobile, isButton }) => {
    const baseClasses = "nav-link transition-colors duration-300";
    const mobileClasses = isMobile ? "block px-6 py-3" : "space-x-8";
    const buttonClasses = isButton ? "bg-purple-600 text-white font-semibold px-5 py-2 rounded-lg hover:bg-purple-700" : "text-gray-400 hover:text-white";
    const activeClass = currentPage === page && !isButton ? "active" : "";

    return (
        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate(page); }} className={`${baseClasses} ${mobileClasses} ${buttonClasses} ${activeClass}`}>
            {label}
        </a>
    );
};

const Header: React.FC<HeaderProps> = ({ onNavigate, currentPage }) => {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    const handleNavigation = (page: Page) => {
        onNavigate(page);
        setIsMobileMenuOpen(false);
    };

    const navItems: { page: Page; label: string }[] = [
        { page: 'home', label: 'Home' },
        { page: 'gallery', label: 'Gallery' },
        { page: 'project-ideas', label: 'Project Ideas' },
        { page: 'about', label: 'About Us' },
        { page: 'pricing', label: 'Pricing' },
        { page: 'faq', label: 'FAQ' },
    ];

    return (
        <header className="bg-slate-950/70 backdrop-blur-lg sticky top-0 z-50 border-b border-slate-800">
            <div className="container mx-auto px-6 py-4 flex justify-between items-center">
                <a href="#" onClick={(e) => { e.preventDefault(); handleNavigation('home'); }} className="flex items-center gap-2">
                    <svg className="h-8 w-8 text-purple-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.438.995s.145.755.438.995l1.003.827c.481.398.668 1.03.26 1.431l-1.296 2.247a1.125 1.125 0 01-1.37.49l-1.217-.456c-.355-.133-.75-.072-1.075.124a6.57 6.57 0 01-.22.127c-.332.183-.582.495-.645.87l-.213 1.281c-.09.542-.56.94-1.11-.94h-2.593c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.063-.374-.313.686-.645-.87a6.52 6.52 0 01-.22-.127c-.324-.196-.72-.257-1.075-.124l-1.217.456a1.125 1.125 0 01-1.37-.49l-1.296-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.437-.995s-.145-.755-.437-.995l-1.004-.827a1.125 1.125 0 01-.26-1.431l1.296-2.247a1.125 1.125 0 011.37-.49l1.217.456c.355.133.75.072 1.075-.124.072-.044.146-.087.22-.127.332-.183.582.495.645-.87l.213-1.281z" />
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <span className="text-2xl font-bold text-white">ProjectBuddy</span>
                </a>
                <nav className="hidden md:flex items-center space-x-8">
                    {navItems.map(item => <NavLink key={item.page} {...item} onNavigate={handleNavigation} currentPage={currentPage} />)}
                    <NavLink page='contact' label='Contact Us' onNavigate={handleNavigation} currentPage={currentPage} isButton />
                </nav>
                <button id="mobile-menu-button" className="md:hidden text-white" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
                    {isMobileMenuOpen ? (
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                         </svg>
                    ) : (
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                         </svg>
                    )}
                </button>
            </div>
            {!isMobileMenuOpen ? null : (
                 <div id="mobile-menu" className="md:hidden bg-slate-900">
                    {navItems.map(item => <NavLink key={item.page} {...item} onNavigate={handleNavigation} currentPage={currentPage} isMobile />)}
                    <NavLink page='contact' label='Contact Us' onNavigate={handleNavigation} currentPage={currentPage} isMobile />
                </div>
            )}
        </header>
    );
};

export default Header;