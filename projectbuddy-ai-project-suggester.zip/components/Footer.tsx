import React, { useState } from 'react';
import Modal from './Modal';

const Footer: React.FC = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);

    const rentalTermsContent = (
        <div className="space-y-4 text-gray-400">
            <p>We offer project kits and electronic components on rent to make learning more affordable and accessible for students. Below are the terms and conditions for renting from ProjectBuddy:</p>
            <div>
                <h3 className="font-bold text-lg text-purple-400">1️⃣ Rental Period</h3>
                <ul className="list-disc list-inside pl-4 mt-1">
                    <li><strong>Minimum Period:</strong> Based on your submission or exhibition date.</li>
                    <li><strong>Extension:</strong> Possible upon request, with additional charges for extra days.</li>
                </ul>
            </div>
            <div>
                <h3 className="font-bold text-lg text-purple-400">2️⃣ Rental Charges & Security Deposit</h3>
                <ul className="list-disc list-inside pl-4 mt-1">
                    <li><strong>Mini Project (Rent):</strong> Based on project complexity.</li>
                    <li><strong>Arduino UNO (Rent):</strong> ₹99/week</li>
                    <li><strong>Sensor Kit (Rent):</strong> ₹49/week</li>
                    <li><strong>Security Deposit:</strong> A refundable deposit (e.g., ₹500 for an Arduino kit) is required for all rentals. It is fully refunded upon the safe and timely return of the kit in good condition.</li>
                </ul>
            </div>
            <div>
                <h3 className="font-bold text-lg text-purple-400">3️⃣ Delivery and Pickup</h3>
                <ul className="list-disc list-inside pl-4 mt-1">
                    <li><strong>Delivery:</strong> Available for an additional cost.</li>
                    <li><strong>Self-Pickup:</strong> You can pick up the kit from our location in Nagpur.</li>
                    <li><strong>Delivery Time:</strong> Generally 3-4 days after confirmation, based on availability and location.</li>
                </ul>
            </div>
            <div>
                <h3 className="font-bold text-lg text-purple-400">4️⃣ Damage/Return Policy</h3>
                <ul className="list-disc list-inside pl-4 mt-1">
                    <li><strong>Return Condition:</strong> Kits must be returned in good working condition with all parts intact.</li>
                    <li><strong>Damaged or Lost Items:</strong> The renter will be liable for repair or replacement charges, which may be deducted from the security deposit.</li>
                </ul>
            </div>
            <div>
                <h3 className="font-bold text-lg text-purple-400">5️⃣ Late Return</h3>
                <ul className="list-disc list-inside pl-4 mt-1">
                    <li>A late fee of ₹50/day will be applied if the kit is not returned by the agreed-upon date.</li>
                </ul>
            </div>
            <p className="pt-4 text-sm text-gray-500">
                <strong>Note:</strong> Delivery and rental charges are non-refundable once the rental period begins. For more details or to book your kit, DM us on Instagram <a href="https://www.instagram.com/project_buddyy_11" target="_blank" rel="noopener noreferrer" className="text-pink-500 underline">@project_buddyy_11</a>.
            </p>
        </div>
    );


    return (
        <>
            <footer className="relative bg-footer bg-cover-center border-t border-slate-800">
                <div className="absolute inset-0 bg-slate-950/80"></div>
                <div className="relative container mx-auto px-6 py-6 text-center text-gray-500">
                    <div className="mb-4">
                        <a href="#" onClick={(e) => { e.preventDefault(); setIsModalOpen(true); }} className="hover:text-gray-300 underline cursor-pointer">
                            Rental Terms & Conditions
                        </a>
                    </div>
                    <p>&copy; {new Date().getFullYear()} ProjectBuddy. All Rights Reserved.</p>
                </div>
            </footer>
            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title="Rental Terms & Conditions"
            >
                {rentalTermsContent}
            </Modal>
        </>
    );
};

export default Footer;