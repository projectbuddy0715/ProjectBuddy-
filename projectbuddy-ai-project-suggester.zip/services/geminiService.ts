
import { GoogleGenAI, Type } from "@google/genai";
import { ProjectSuggestion } from '../types';

const getProjectSuggestions = async (
  branch: string,
  year: string,
  interest: string
): Promise<ProjectSuggestion[]> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `Act as an expert engineering project consultant for college students.
  
  Your task is to generate 3 innovative and practical project ideas for a student with the following profile:
  - Branch: ${branch}
  - Year of Study: ${year}
  - Area of Interest: ${interest}
  
  The ideas should be tailored to their skill level and relevant to their field of study. For each project, provide a concise title and a compelling one-sentence description. Ensure the output is a valid JSON array.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: {
                type: Type.STRING,
                description: "The concise title of the project idea.",
              },
              description: {
                type: Type.STRING,
                description: "A compelling one-sentence description of the project.",
              },
            },
            required: ["title", "description"],
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const suggestions: ProjectSuggestion[] = JSON.parse(jsonText);
    return suggestions;
  } catch (error) {
    console.error("Error fetching project suggestions:", error);
    throw new Error("Failed to get suggestions from AI. Please try again.");
  }
};

export default getProjectSuggestions;
