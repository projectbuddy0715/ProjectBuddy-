import React, { useState } from 'react';
import useScrollAnimation from '../hooks/useScrollAnimation';
import getProjectSuggestions from '../services/geminiService';
import { ProjectSuggestion } from '../types';

const hardwareProjectsList = [
    "Automatic Plant Watering System", "Smart Traffic Light Control", "Obstacle Avoiding Robot",
    "Line Following Robot", "Home Security System with GSM Alert", "Digital Dice Using Arduino",
    "Automatic Street Light", "Temperature and Humidity Monitor", "Fire Alarm System",
    "Gesture Controlled Robot", "Smart Blind Stick for Visually Impaired", "Voice Controlled Home Appliances",
    "RFID Based Door Lock System", "Smart Energy Meter", "Bluetooth Controlled Car",
    "Soil pH and Moisture Monitoring System", "Water Level Indicator & Controller", "IR Remote Controlled Home Appliances",
    "Automatic Pet Feeder", "Electronic Voting Machine (EVM)", "Parking Sensor System",
    "Turbidity Sensor System", "Li-Fi Communication Technology Prototype", "Electrolysis of Water",
    "Radar System for Obstacle Detection", "Rainwater Detection & Alert System", "Fire Detector",
    "Smoke Detector", "Water ATM Prototype", "And many more..."
];

const softwareProjectsList = [
    "Library Management System", "Online Quiz System", "Student Attendance Management System",
    "To-Do List App", "Weather Forecast App", "Expense Tracker", "Online Voting System",
    "Chat Application", "Online Food Ordering System", "Hotel Management System", "Portfolio Website",
    "E-commerce Website", "Movie Recommendation System", "Online Resume Builder", "Music Player App",
    "Simple Banking System", "Inventory Management System", "Health Monitoring App", "Recipe Finder App",
    "AI Chatbot for Customer Support", "AI Voice Assistant", "Edu-Track System",
    "Virtual Chemistry Lab", "Fitness Tracker App", "Smart Reminder App", "Virtual Classroom App",
    "Expense Splitter App", "Personal Diary App", "AI-based Resume Screener", "Smart Home Control App",
    "And many more..."
];

const ProjectSuggester: React.FC = () => {
    const [branch, setBranch] = useState('cse');
    const [year, setYear] = useState('2nd');
    const [interest, setInterest] = useState('iot');
    const [suggestions, setSuggestions] = useState<ProjectSuggestion[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGetSuggestions = async () => {
        setLoading(true);
        setError(null);
        setSuggestions([]);
        try {
            const result = await getProjectSuggestions(branch, year, interest);
            setSuggestions(result);
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError("An unknown error occurred.");
            }
        } finally {
            setLoading(false);
        }
    };
    
    return (
        <section id="project-suggester" className="py-20">
            <div className="container mx-auto px-6 animate-on-scroll">
                <div className="bg-gradient-to-r from-slate-900 to-gray-900/50 rounded-xl p-8 md:p-12 text-center border border-slate-800">
                    <h2 className="text-4xl md:text-5xl font-black text-white">Find Your <span className="gradient-text">Perfect Project</span></h2>
                    <p className="text-gray-400 max-w-2xl mx-auto mt-4 mb-8">Tell us about yourself, and our AI will suggest some project ideas tailored just for you!</p>
                    <div id="suggester-form" className="grid grid-cols-1 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
                        <select value={branch} onChange={(e) => setBranch(e.target.value)} className="bg-slate-800 border border-slate-700 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5">
                            <option value="cse">Computer Science / IT</option>
                            <option value="ece">Electronics & Comm.</option>
                            <option value="mech">Mechanical</option>
                        </select>
                        <select value={year} onChange={(e) => setYear(e.target.value)} className="bg-slate-800 border border-slate-700 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5">
                            <option value="2nd">2nd Year</option>
                            <option value="3rd">3rd Year</option>
                            <option value="final">Final Year</option>
                        </select>
                        <select value={interest} onChange={(e) => setInterest(e.target.value)} className="bg-slate-800 border border-slate-700 text-white text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 block w-full p-2.5">
                            <option value="iot">IoT & Hardware</option>
                            <option value="web">Web Development</option>
                            <option value="ml">AI / Machine Learning</option>
                            <option value="robotics">Robotics</option>
                        </select>
                        <button onClick={handleGetSuggestions} disabled={loading} className="w-full bg-purple-600 text-white font-semibold py-2.5 rounded-lg hover:bg-purple-700 transition-colors duration-300 disabled:bg-purple-800 disabled:cursor-not-allowed">
                            {loading ? 'Thinking...' : 'Get Suggestions'}
                        </button>
                    </div>
                    <div id="suggestions-result" className="mt-8 text-left max-w-4xl mx-auto">
                        {loading && (
                            <div className="flex justify-center items-center">
                                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                <p>Generating ideas...</p>
                            </div>
                        )}
                        {error && (
                            <div className="bg-red-500/20 border border-red-600 text-red-300 p-4 rounded-lg">
                                <p><strong>Error:</strong> {error}</p>
                            </div>
                        )}
                        {suggestions.length > 0 && (
                            <div>
                                <h3 className="text-xl font-bold text-white mb-4">Here are some AI-powered suggestions for you:</h3>
                                <div className="space-y-3">
                                    {suggestions.map((p, i) => (
                                        <div key={i} className="bg-slate-800/50 p-4 rounded-lg">
                                            <h4 className="font-semibold text-white">{p.title}</h4>
                                            <p className="text-sm text-gray-400">{p.description}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
};


const ProjectIdeasPage: React.FC = () => {
    useScrollAnimation();
    const SparkleIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09Z" />
        </svg>
    );

    return (
        <>
            <section className="py-20 bg-slate-900/70">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16 animate-on-scroll">
                        <h2 className="text-4xl md:text-5xl font-black text-white">Project Guidance We <span className="gradient-text">Offer</span></h2>
                        <p className="text-gray-400 max-w-3xl mx-auto mt-4">
                            Explore our collection of updated hardware and software mini projects designed for engineering students. We also develop custom projects tailored to your unique ideas.
                        </p>
                    </div>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-4 animate-on-scroll">
                        <div className="relative bg-circuit bg-cover-center rounded-xl overflow-hidden p-8 border border-slate-700">
                             <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"></div>
                             <div className="relative z-10">
                                <h3 className="text-2xl font-bold text-white mb-6 text-center lg:text-left">Hardware Mini Projects</h3>
                                <ul className="space-y-3 text-gray-300">
                                    {hardwareProjectsList.map((project, index) => (
                                        <li key={index} className="flex items-start">
                                            <span className="mr-3 mt-1 flex-shrink-0"><SparkleIcon /></span>
                                            <span>{project}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                         <div className="relative bg-code bg-cover-center rounded-xl overflow-hidden p-8 border border-slate-700">
                             <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"></div>
                             <div className="relative z-10">
                                <h3 className="text-2xl font-bold text-white mb-6 text-center lg:text-left">Software Mini Projects</h3>
                                <ul className="space-y-3 text-gray-300">
                                    {softwareProjectsList.map((project, index) => (
                                        <li key={index} className="flex items-start">
                                            <span className="mr-3 mt-1 flex-shrink-0"><SparkleIcon /></span>
                                            <span>{project}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <ProjectSuggester />
        </>
    );
};

export default ProjectIdeasPage;