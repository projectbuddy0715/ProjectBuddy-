
import React, { useState } from 'react';
import useScrollAnimation from '../hooks/useScrollAnimation';
import { FAQ } from '../types';

const faqData: FAQ[] = [
    { question: "How does the rental process work?", answer: "It's simple! First, fill out our booking form. We'll confirm your order and rental period. After you make the payment (including a refundable security deposit), you can pick up the kit or have it delivered. Return it on time in good condition, and we'll refund your deposit." },
    { question: "What happens if I damage a rented component?", answer: "You will be liable for the repair or replacement cost of any damaged or lost items. This cost may be deducted from your security deposit. We recommend handling all components with care." },
    { question: "Do you provide support for students outside of Nagpur?", answer: "Yes! While our physical kit rentals are primarily focused on Nagpur, our DIY kits can be shipped anywhere in India. More importantly, our one-on-one mentorship and project guidance are provided online, making them accessible to students everywhere." },
    { question: "What kind of mentorship is included?", answer: "Our mentorship includes help with understanding the project's code, circuit diagram, and overall functionality. We guide you through the building process, help with debugging, and provide tips for your final presentation or viva to ensure you can explain your project confidently." },
];

const FAQItem: React.FC<{ faq: FAQ; isOpen: boolean; onClick: () => void; }> = ({ faq, isOpen, onClick }) => {
    return (
        <div className={`faq-item bg-slate-900 border border-slate-800 rounded-lg ${isOpen ? 'active' : ''}`}>
            <button onClick={onClick} className="faq-question w-full flex justify-between items-center text-left p-6 hover:bg-slate-800/50">
                <span className="text-lg font-semibold text-white">{faq.question}</span>
                <svg className="faq-arrow h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            <div className="faq-answer px-6 text-gray-400">
                <p>{faq.answer}</p>
            </div>
        </div>
    );
};


const FAQPage: React.FC = () => {
    useScrollAnimation();
    const [openIndex, setOpenIndex] = useState<number | null>(null);

    const handleItemClick = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <section className="py-20">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16 animate-on-scroll">
                    <h2 className="text-4xl md:text-5xl font-black text-white">Frequently Asked <span className="gradient-text">Questions</span></h2>
                    <p className="text-gray-400 max-w-2xl mx-auto mt-4">Have questions? We've got answers. If you can't find what you're looking for, feel free to contact us.</p>
                </div>
                <div className="max-w-3xl mx-auto space-y-4 animate-on-scroll">
                    {faqData.map((faq, index) => (
                        <FAQItem 
                            key={index} 
                            faq={faq} 
                            isOpen={openIndex === index}
                            onClick={() => handleItemClick(index)} 
                        />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default FAQPage;