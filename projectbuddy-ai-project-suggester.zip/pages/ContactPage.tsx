
import React from 'react';
import useScrollAnimation from '../hooks/useScrollAnimation';

const ContactPage: React.FC = () => {
    useScrollAnimation();
    
    return (
        <section className="gradient-bg-section">
            <div className="container mx-auto px-6 py-20 text-center animate-on-scroll">
                <h2 className="text-4xl md:text-5xl font-black text-white mb-4 hero-title-shadow">Ready to Start Your Next Project?</h2>
                <p className="text-violet-200 max-w-2xl mx-auto mb-8">Don't let project deadlines stress you out. Reach out to us today and let's build something amazing together!</p>
                <div className="flex justify-center items-center flex-wrap gap-4">
                    <a href="https://forms.gle/u3VxhUY4fofGzPiV8" target="_blank" rel="noopener noreferrer" className="bg-white text-violet-700 font-bold px-8 py-4 rounded-lg text-lg transform hover:scale-105 transition-transform duration-300 glow-effect">Fill Out Booking Form</a>
                    <a href="https://www.instagram.com/project_buddyy_11" target="_blank" rel="noopener noreferrer" className="bg-pink-600 text-white font-bold px-8 py-4 rounded-lg text-lg transform hover:scale-105 transition-transform duration-300 flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                        </svg>
                        Message on Instagram
                    </a>
                    <a href="https://wa.me/919373286008" target="_blank" rel="noopener noreferrer" className="bg-green-500 text-white font-bold px-8 py-4 rounded-lg text-lg transform hover:scale-105 transition-transform duration-300 flex items-center gap-2">
                       <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                           <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                       </svg>
                       Chat on WhatsApp
                    </a>
                </div>
            </div>
        </section>
    );
};

export default ContactPage;
