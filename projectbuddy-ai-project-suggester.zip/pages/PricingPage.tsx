import React, { useState } from 'react';
import useScrollAnimation from '../hooks/useScrollAnimation';

const PricingPage: React.FC = () => {
    useScrollAnimation();
    const [activeTab, setActiveTab] = useState<'diy' | 'rental'>('diy');

    const diyKitPricing = (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-5xl mx-auto items-start">
             <div className="bg-slate-900 rounded-xl p-8 flex flex-col border border-slate-800 h-full animate-on-scroll" style={{transitionDelay: '100ms'}}>
                <h3 className="text-xl font-bold text-white">Basic DIY Kits</h3>
                <p className="text-gray-400 mt-1">Sensors, Arduino, etc.</p>
                <div className="my-6"><span className="text-4xl font-extrabold text-white">₹400 – ₹800</span></div>
                <ul className="space-y-3 text-gray-400 flex-grow">
                    <li className="flex items-center"><span className="text-green-400 mr-3">✅</span>All Required Components</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✅</span>Source Code & Libraries</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✅</span>Step-by-Step Assembly Guide</li>
                </ul>
                <a href="https://forms.gle/u3VxhUY4fofGzPiV8" target="_blank" rel="noopener noreferrer" className="mt-8 w-full text-center bg-slate-700 text-white font-semibold py-3 rounded-lg hover:bg-slate-600 transition-colors duration-300">Choose Plan</a>
            </div>
            <div className="bg-gradient-to-br from-violet-800 to-purple-700 rounded-xl p-8 flex flex-col border-2 border-purple-500 relative transform lg:scale-110 shadow-2xl shadow-purple-500/30 h-full animate-on-scroll" style={{transitionDelay: '200ms'}}>
                <div className="absolute top-0 right-8 -mt-4 bg-yellow-400 text-gray-900 font-bold text-sm px-3 py-1 rounded-full uppercase">Best Value</div>
                <h3 className="text-2xl font-bold text-white">Intermediate DIY Kits</h3>
                <p className="text-purple-200 mt-1">IoT / Robotics Projects</p>
                <div className="my-6"><span className="text-5xl font-extrabold text-white">₹1000 – ₹2000</span></div>
                <ul className="space-y-3 text-purple-100 flex-grow">
                    <li className="flex items-center"><span className="text-green-300 mr-3">✅</span>All Basic Kit Features</li>
                    <li className="flex items-center"><span className="text-green-300 mr-3">✅</span>Advanced/IoT Components</li>
                    <li className="flex items-center"><span className="text-green-300 mr-3">✅</span><strong>Mentorship Available</strong></li>
                    <li className="flex items-center"><span className="text-green-300 mr-3">✅</span>Project Report & PPT Template</li>
                </ul>
                <a href="https://forms.gle/u3VxhUY4fofGzPiV8" target="_blank" rel="noopener noreferrer" className="mt-8 w-full text-center bg-white text-violet-700 font-bold py-3 rounded-lg hover:bg-gray-200 transition-colors duration-300 glow-effect animated-glow">Choose Plan</a>
            </div>
            <div className="bg-slate-900 rounded-xl p-8 flex flex-col border border-slate-800 h-full animate-on-scroll" style={{transitionDelay: '300ms'}}>
                <h3 className="text-xl font-bold text-white">Advanced DIY Kits</h3>
                <p className="text-gray-400 mt-1">AI, Automation & Custom Ideas</p>
                <div className="my-6"><span className="text-4xl font-extrabold text-white">Custom Quote</span></div>
                <ul className="space-y-3 text-gray-400 flex-grow">
                    <li className="flex items-center"><span className="text-green-400 mr-3">✅</span>Components for Your Idea</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✅</span>Custom Codebase</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✅</span>Personalized Guidance</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✅</span>Full Mentorship Available</li>
                </ul>
                <a href="https://forms.gle/u3VxhUY4fofGzPiV8" target="_blank" rel="noopener noreferrer" className="mt-8 w-full text-center bg-slate-700 text-white font-semibold py-3 rounded-lg hover:bg-slate-600 transition-colors duration-300">Request a Quote</a>
            </div>
        </div>
    );

    const rentalPricing = (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-slate-900 rounded-xl p-8 border border-slate-800 flex flex-col">
                <h3 className="text-2xl font-bold text-white mb-2">Rental Kits</h3>
                <p className="text-gray-400 mt-1 flex-grow">Access hardware without buying. Perfect for short-term projects.</p>
                <div className="my-6 space-y-2">
                    <p><span className="text-2xl font-bold text-white">₹500 – ₹1200</span><span className="text-gray-400"> for Project Kits</span></p>
                    <p><span className="text-2xl font-bold text-white">₹100 – ₹300</span><span className="text-gray-400"> for Components</span></p>
                </div>
                <ul className="space-y-3 text-gray-400 flex-grow">
                    <li className="flex items-center"><span className="text-green-400 mr-3">✔</span>Rent a Complete Project Kit</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✔</span>Rent Individual Components</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✔</span>Refundable Security Deposit (₹500 - ₹1000)</li>
                </ul>
                <a href="https://forms.gle/u3VxhUY4fofGzPiV8" target="_blank" rel="noopener noreferrer" className="mt-8 w-full text-center bg-slate-700 text-white font-semibold py-3 rounded-lg hover:bg-slate-600 transition-colors duration-300">Rent Now</a>
            </div>
            <div className="bg-slate-900 rounded-xl p-8 border border-slate-800 flex flex-col">
                <h3 className="text-2xl font-bold text-white mb-2">Mentorship & Guidance</h3>
                 <p className="text-gray-400 mt-1 flex-grow">Already have components? Get expert guidance to ensure your project is a success.</p>
                 <div className="my-6 space-y-2">
                    <p><span className="text-2xl font-bold text-white">Starting from ₹500</span><span className="text-gray-400"> for Mini Projects</span></p>
                    <p><span className="text-2xl font-bold text-white">Custom Quote</span><span className="text-gray-400"> for Major Projects</span></p>
                </div>
                <ul className="space-y-3 text-gray-400 flex-grow">
                    <li className="flex items-center"><span className="text-green-400 mr-3">✔</span>One-on-One Guidance</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✔</span>Code Debugging & Support</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✔</span>Report & PPT Assistance</li>
                    <li className="flex items-center"><span className="text-green-400 mr-3">✔</span>Viva Preparation</li>
                </ul>
                <a href="https://forms.gle/u3VxhUY4fofGzPiV8" target="_blank" rel="noopener noreferrer" className="mt-8 w-full text-center bg-slate-700 text-white font-semibold py-3 rounded-lg hover:bg-slate-600 transition-colors duration-300">Get a Mentor</a>
            </div>
        </div>
    );

    return (
        <section className="relative py-20 bg-pricing bg-cover-center">
            <div className="absolute inset-0 bg-slate-950/90"></div>
            <div className="container mx-auto px-6 relative z-10">
                <div className="text-center mb-12 animate-on-scroll">
                    <h2 className="text-4xl md:text-5xl font-black text-white">Flexible <span className="gradient-text">Pricing for Every Need</span></h2>
                    <p className="text-gray-400 max-w-2xl mx-auto mt-4">Choose the perfect package that fits your learning style and budget.</p>
                </div>
                <div className="flex justify-center mb-10 animate-on-scroll">
                    <div className="bg-slate-800 rounded-lg p-1 flex space-x-1">
                        <button onClick={() => setActiveTab('diy')} className={`pricing-tab px-6 py-2 text-sm font-semibold rounded-md transition-colors duration-300 ${activeTab === 'diy' ? 'active' : ''}`}>DIY Kits</button>
                        <button onClick={() => setActiveTab('rental')} className={`pricing-tab px-6 py-2 text-sm font-semibold rounded-md transition-colors duration-300 ${activeTab === 'rental' ? 'active' : ''}`}>Rental & Mentorship</button>
                    </div>
                </div>
                {activeTab === 'diy' ? diyKitPricing : rentalPricing}
                 <div className="text-center mt-16 animate-on-scroll">
                    <p className="text-gray-500 text-sm max-w-3xl mx-auto">
                        All prices depend on project complexity and requirements. We provide DIY kits, rentals, and mentorship for educational purposes only.
                    </p>
                </div>
            </div>
        </section>
    );
};

export default PricingPage;