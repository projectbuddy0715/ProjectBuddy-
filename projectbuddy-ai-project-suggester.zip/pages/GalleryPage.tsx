
import React from 'react';
import useScrollAnimation from '../hooks/useScrollAnimation';
import { Project } from '../types';

const galleryProjects: Project[] = [
    { title: "Obstacle Avoiding Robot", description: "An autonomous robot that navigates its environment using ultrasonic sensors.", image: "https://picsum.photos/seed/robot/600/400" },
    { title: "IoT Weather Station", description: "Monitors real-time weather data and uploads it to the cloud for remote access.", image: "https://picsum.photos/seed/weather/600/400" },
    { title: "Smart Home Automation", description: "Control lights, fans, and other appliances using a custom smartphone app.", image: "https://picsum.photos/seed/smarthome/600/400" },
    { title: "Real-time Chat App", description: "A web application allowing multiple users to chat instantly and securely.", image: "https://picsum.photos/seed/chatapp/600/400" },
    { title: "E-commerce Website", description: "A fully functional online store with product management and payment integration.", image: "https://picsum.photos/seed/ecommerce/600/400" },
    { title: "Ultrasonic Parking Sensor", description: "A device that alerts drivers with a buzzer when they get too close to an object.", image: "https://picsum.photos/seed/parking/600/400" },
];

const GalleryPage: React.FC = () => {
    useScrollAnimation();
    
    return (
        <section className="py-20">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16 animate-on-scroll">
                    <h2 className="text-4xl md:text-5xl font-black text-white">DIY Project Kit <span className="gradient-text">Gallery</span></h2>
                    <p className="text-gray-400 max-w-2xl mx-auto mt-4">Explore the variety of DIY kits we offer for different skill levels and interests.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {galleryProjects.map((project, index) => (
                        <div key={index} className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden group animate-on-scroll" style={{ transitionDelay: `${(index % 3) * 100 + 100}ms` }}>
                            <img src={project.image} alt={project.title} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
                            <div className="p-6">
                                <h3 className="text-xl font-bold text-white">{project.title}</h3>
                                <p className="text-gray-400 mt-2 text-sm">{project.description}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default GalleryPage;