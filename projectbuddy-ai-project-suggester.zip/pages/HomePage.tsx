import React, { useEffect, useRef, useState, useCallback } from 'react';
import useScrollAnimation from '../hooks/useScrollAnimation';
import { Page, Project, Testimonial } from '../types';

const featuredProjects: Project[] = [
    { title: "Obstacle Avoiding Robot", description: "An autonomous robot that navigates its environment using ultrasonic sensors.", image: "https://picsum.photos/seed/robot/600/400" },
    { title: "IoT Weather Station", description: "Monitors real-time weather data and uploads it to the cloud for remote access.", image: "https://picsum.photos/seed/weather/600/400" },
    { title: "E-commerce Website", description: "A fully functional online store with product management and payment integration.", image: "https://picsum.photos/seed/ecommerce/600/400" },
    { title: "Smart Home Automation", description: "Control lights, fans, and other appliances using a custom smartphone app.", image: "https://picsum.photos/seed/smarthome/600/400" },
];

const testimonials: Testimonial[] = [
    { quote: "\"The comprehensive package was a lifesaver! I got a high-quality project, a detailed report, and an amazing PPT. The after-sales support was fantastic and helped me clear all my doubts before the final presentation.\"", name: "Aniket R.", title: "Computer Science Student", initials: "AR", color: "bg-purple-600" },
    { quote: "\"Renting the sensor kit was so affordable and convenient. I didn't have to buy expensive components for a one-time project. ProjectBuddy is a must for any engineering student on a budget!\"", name: "Priya S.", title: "Electronics Engineering", initials: "PS", color: "bg-pink-600" },
    { quote: "\"I had a unique project idea, and the team built it exactly as I envisioned. The custom project service is top-notch. Highly recommended for their professionalism and technical skills.\"", name: "Vikram K.", title: "Mechanical Engineering", initials: "VK", color: "bg-teal-600" },
];


const Stats: React.FC = () => {
    const statsRef = useRef<HTMLDivElement>(null);
    const [animated, setAnimated] = useState(false);
    const statsData = [{ target: 200, suffix: '+' }, { target: 150, suffix: '+' }, { target: 98, suffix: '%' }];

    const animateStat = (el: Element, target: number, suffix: string) => {
        let current = 0;
        const increment = target / 100;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                clearInterval(timer);
                el.textContent = target + suffix;
            } else {
                el.textContent = Math.ceil(current) + suffix;
            }
        }, 20);
    };

    useEffect(() => {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !animated) {
                    const statsElements = statsRef.current?.querySelectorAll('[data-stat-target]');
                    statsElements?.forEach((statEl, index) => {
                        animateStat(statEl, statsData[index].target, statsData[index].suffix);
                    });
                    setAnimated(true);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        if (statsRef.current) {
            observer.observe(statsRef.current);
        }

        return () => {
            if (statsRef.current) {
                // eslint-disable-next-line react-hooks/exhaustive-deps
                observer.unobserve(statsRef.current);
            }
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [animated]);

    return (
        <section id="stats" className="py-20">
            <div ref={statsRef} className="container mx-auto px-6 animate-on-scroll">
                <div className="bg-gradient-to-r from-slate-900 to-gray-900/50 rounded-xl p-8 md:p-12 border border-slate-800">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                        <div>
                            <h3 className="text-5xl font-black gradient-text" data-stat-target="200">0+</h3>
                            <p className="text-gray-400 mt-2">Projects Delivered</p>
                        </div>
                        <div>
                            <h3 className="text-5xl font-black gradient-text" data-stat-target="150">0+</h3>
                            <p className="text-gray-400 mt-2">Happy Students</p>
                        </div>
                        <div>
                            <h3 className="text-5xl font-black gradient-text" data-stat-target="98">0%</h3>
                            <p className="text-gray-400 mt-2">Satisfaction Rate</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

const TestimonialCarousel: React.FC = () => {
    const [currentIndex, setCurrentIndex] = useState(0);

    const nextSlide = useCallback(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
    }, []);

    const prevSlide = () => {
        setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
    };

    useEffect(() => {
        const interval = setInterval(nextSlide, 5000);
        return () => clearInterval(interval);
    }, [nextSlide]);

    return (
        <section className="py-20">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16 animate-on-scroll">
                    <h2 className="text-4xl md:text-5xl font-black text-white">What Our <span className="gradient-text">Clients Say</span></h2>
                    <p className="text-gray-400 max-w-2xl mx-auto mt-4">Real feedback from students who trusted ProjectBuddy for their success.</p>
                </div>
                <div className="relative max-w-3xl mx-auto animate-on-scroll">
                    <div className="overflow-hidden">
                        {testimonials.map((testimonial, index) => (
                            <div key={index} className={`testimonial-slide ${index === currentIndex ? '' : 'hidden'}`}>
                                <div className="bg-slate-900 p-8 rounded-xl border border-slate-800 text-center">
                                    <p className="text-gray-400 mb-6 italic">{testimonial.quote}</p>
                                    <div className="flex items-center justify-center">
                                        <div className="flex-shrink-0">
                                            <span className={`inline-flex items-center justify-center h-12 w-12 rounded-full ${testimonial.color}`}>
                                                <span className="text-lg font-medium text-white">{testimonial.initials}</span>
                                            </span>
                                        </div>
                                        <div className="ml-4 text-left">
                                            <div className="text-lg font-semibold text-white">{testimonial.name}</div>
                                            <div className="text-sm text-gray-500">{testimonial.title}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                    <button onClick={prevSlide} className="absolute top-1/2 left-0 md:-left-16 transform -translate-y-1/2 bg-slate-800/50 hover:bg-slate-700/80 rounded-full p-3 text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
                    </button>
                    <button onClick={nextSlide} className="absolute top-1/2 right-0 md:-right-16 transform -translate-y-1/2 bg-slate-800/50 hover:bg-slate-700/80 rounded-full p-3 text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
                    </button>
                </div>
            </div>
        </section>
    );
};

interface HomePageProps {
    onNavigate: (page: Page) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
    useScrollAnimation();
    
    return (
        <div id="home">
            <section className="relative bg-hero bg-cover-center text-white pt-28 pb-32">
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent"></div>
                <div className="container mx-auto px-6 text-center relative z-10 animate-on-scroll">
                    <h1 className="text-4xl md:text-6xl font-black leading-tight mb-4 hero-title-shadow">Build It Yourself with Our DIY Kits & Mentorship</h1>
                    <p className="text-lg md:text-xl max-w-3xl mx-auto mb-8 text-violet-200">Empower your engineering journey by learning through doing. Get complete DIY kits, flexible rentals, and expert guidance.</p>
                    <div className="flex justify-center items-center flex-wrap gap-4">
                        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('gallery'); }} className="bg-white text-violet-700 font-bold px-8 py-3 rounded-lg text-lg hover:bg-gray-100 transform hover:scale-105 transition-all duration-300 glow-effect">
                           Browse DIY Kits
                        </a>
                         <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('pricing'); }} className="border-2 border-white text-white font-bold px-8 py-3 rounded-lg text-lg hover:bg-white hover:text-violet-700 transform hover:scale-105 transition-all duration-300">
                            View Rental Plans
                        </a>
                    </div>
                </div>
            </section>
            
            <section className="py-4 bg-purple-900/50 border-y border-purple-700">
                 <div className="container mx-auto px-6 text-center animate-on-scroll">
                     <p className="text-lg font-semibold text-white">ProjectBuddy — <span className="gradient-text">Your Partner in Hands-On Learning</span> 🚀</p>
                 </div>
            </section>

             <section className="py-20 bg-slate-900/70">
                <div className="container mx-auto px-6">
                     <div className="text-center mb-16 animate-on-scroll">
                        <h2 className="text-4xl md:text-5xl font-black text-white">Why <span className="gradient-text">Choose Us?</span></h2>
                        <p className="text-gray-400 max-w-2xl mx-auto mt-4">We're more than just a kit provider. We're your dedicated partner for academic success.</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
                        <div className="relative text-center p-6 animate-on-scroll bg-slate-900/50 rounded-lg border border-slate-800 overflow-hidden" style={{transitionDelay: '100ms'}}>
                            <svg xmlns="http://www.w3.org/2000/svg" className="absolute -top-8 -left-8 h-32 w-32 text-slate-800/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="0.5"><path strokeLinecap="round" strokeLinejoin="round" d="M21 13.255A23.931 23.931 0 0 1 12 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2m4 6h.01M5 20h14a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2z" /></svg>
                            <div className="relative z-10"><div className="mx-auto mb-4 bg-purple-600/20 text-purple-400 rounded-lg h-16 w-16 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg></div><h3 className="text-xl font-bold text-white mb-2">Complete DIY Kits</h3><p className="text-gray-400">Get all components, code, and resources needed to start building immediately.</p></div>
                        </div>
                         <div className="relative text-center p-6 animate-on-scroll bg-slate-900/50 rounded-lg border border-slate-800 overflow-hidden" style={{transitionDelay: '200ms'}}>
                            <svg xmlns="http://www.w3.org/2000/svg" className="absolute -top-8 -left-8 h-32 w-32 text-slate-800/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="0.5"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0 1 15.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 0 1 3 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 0 0-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 0 1-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 0 0 3 15h-.75M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>
                            <div className="relative z-10"><div className="mx-auto mb-4 bg-purple-600/20 text-purple-400 rounded-lg h-16 w-16 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01" /></svg></div><h3 className="text-xl font-bold text-white mb-2">Affordable Rental Plans</h3><p className="text-gray-400">Access the hardware you need without the high cost. Perfect for one-time projects.</p></div>
                        </div>
                         <div className="relative text-center p-6 animate-on-scroll bg-slate-900/50 rounded-lg border border-slate-800 overflow-hidden" style={{transitionDelay: '300ms'}}>
                            <svg xmlns="http://www.w3.org/2000/svg" className="absolute -top-8 -left-8 h-32 w-32 text-slate-800/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="0.5"><path strokeLinecap="round" strokeLinejoin="round" d="M11.42 15.17 17.25 21A2.652 2.652 0 0 0 21 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.73-.726 1.196-1.025a4.5 4.5 0 0 0-4.242-4.242-1.027-1.027-1.027-1.027a4.5 4.5 0 0 0-1.025 1.196L3 11.25l2.496 2.496L6 18l2.496-2.496L11.42 15.17Z" /></svg>
                            <div className="relative z-10"><div className="mx-auto mb-4 bg-purple-600/20 text-purple-400 rounded-lg h-16 w-16 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg></div><h3 className="text-xl font-bold text-white mb-2">Expert Mentorship</h3><p className="text-gray-400">Our job isn't done until you've successfully built and presented your project. We're here to guide you.</p></div>
                        </div>
                    </div>
                </div>
            </section>
            
            <section className="py-20">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16 animate-on-scroll">
                        <h2 className="text-4xl md:text-5xl font-black text-white">Popular <span className="gradient-text">DIY Kits</span></h2>
                        <p className="text-gray-400 max-w-2xl mx-auto mt-4">Check out some of our most popular DIY project kits that students love.</p>
                    </div>
                    <div className="relative animate-on-scroll">
                        <div className="flex overflow-x-auto snap-x snap-mandatory no-scrollbar">
                            {featuredProjects.map((project, index) => (
                                <div key={index} className="featured-project-slide snap-start flex-shrink-0 w-full md:w-1/2 lg:w-1/3 p-4">
                                    <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden group h-full flex flex-col">
                                        <img src={project.image} alt={project.title} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
                                        <div className="p-6 flex flex-col flex-grow">
                                            <h3 className="text-xl font-bold text-white">{project.title}</h3>
                                            <p className="text-gray-400 mt-2 text-sm flex-grow">{project.description}</p>
                                            <button onClick={() => onNavigate('gallery')} className="mt-4 text-sm font-semibold text-purple-400 hover:text-white text-left">Explore Kit &rarr;</button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>
            
            <section className="py-20 bg-slate-900/70">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16 animate-on-scroll">
                        <h2 className="text-4xl md:text-5xl font-black text-white">How It <span className="gradient-text">Works</span></h2>
                        <p className="text-gray-400 max-w-2xl mx-auto mt-4">A simple, four-step process to build your project.</p>
                    </div>
                    <div className="relative max-w-4xl mx-auto">
                        <div className="hidden md:block absolute top-10 left-0 w-full h-0.5 bg-slate-700 -translate-y-1/2"></div>
                        <div className="md:hidden absolute top-0 left-10 w-0.5 h-full bg-slate-700"></div>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-y-16 md:gap-8 relative">
                            <div className="animate-on-scroll flex md:flex-col items-center text-center md:text-center" style={{transitionDelay: '100ms'}}>
                                <div className="flex-shrink-0 mx-auto mb-0 md:mb-4 bg-slate-900 border-2 border-purple-500 rounded-full h-20 w-20 flex items-center justify-center relative"><svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M21 13.255A23.931 23.931 0 0 1 12 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2m4 6h.01M5 20h14a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2z" /></svg></div>
                                <div className="ml-6 md:ml-0"><h3 className="text-lg font-bold text-white mb-2 text-left md:text-center">Choose Your Kit</h3><p className="text-sm text-gray-400 text-left md:text-center">Browse our DIY kits or select a rental plan that fits your needs.</p></div>
                            </div>
                            <div className="animate-on-scroll flex md:flex-col items-center text-center md:text-center" style={{transitionDelay: '200ms'}}>
                                <div className="flex-shrink-0 mx-auto mb-0 md:mb-4 bg-slate-900 border-2 border-purple-500 rounded-full h-20 w-20 flex items-center justify-center relative"><svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z" /></svg></div>
                                <div className="ml-6 md:ml-0"><h3 className="text-lg font-bold text-white mb-2 text-left md:text-center">Receive Your Kit</h3><p className="text-sm text-gray-400 text-left md:text-center">Get all components and guides delivered to your doorstep.</p></div>
                            </div>
                            <div className="animate-on-scroll flex md:flex-col items-center text-center md:text-center" style={{transitionDelay: '300ms'}}>
                                <div className="flex-shrink-0 mx-auto mb-0 md:mb-4 bg-slate-900 border-2 border-purple-500 rounded-full h-20 w-20 flex items-center justify-center relative"><svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.311a7.5 7.5 0 0 1-7.5 0c.407.62.904 1.234 1.574 1.764a7.5 7.5 0 0 1 4.352 0c.67-.53 1.167-1.144 1.574-1.764z" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.002a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0zm0 0V2.25m0 3.752a3.75 3.75 0 0 0 7.5 0V2.25" /></svg></div>
                                <div className="ml-6 md:ml-0"><h3 className="text-lg font-bold text-white mb-2 text-left md:text-center">Build & Learn</h3><p className="text-sm text-gray-400 text-left md:text-center">Assemble your project with step-by-step guides and mentor support.</p></div>
                            </div>
                            <div className="animate-on-scroll flex md:flex-col items-center text-center md:text-center" style={{transitionDelay: '400ms'}}>
                                <div className="flex-shrink-0 mx-auto mb-0 md:mb-4 bg-slate-900 border-2 border-purple-500 rounded-full h-20 w-20 flex items-center justify-center relative"><svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M4.26 10.147a60.438 60.438 0 0 0-.491 6.347A48.627 48.627 0 0 1 12 20.904a48.627 48.627 0 0 1 8.232-4.41 60.46 60.46 0 0 0-.491-6.347m-15.482 0a50.57 50.57 0 0 0-2.658-.813A59.906 59.906 0 0 1 12 3.493a59.903 59.903 0 0 1 10.399 5.84c-.896.248-1.783.52-2.658.814m-15.482 0A50.697 50.697 0 0 1 12 13.489a50.702 50.702 0 0 1 7.74-3.342M12 21a48.849 48.849 0 0 0-3.478-.397c-3.587-.34-6.592-1.263-9.522-2.925" /></svg></div>
                                <div className="ml-6 md:ml-0"><h3 className="text-lg font-bold text-white mb-2 text-left md:text-center">Present with Confidence</h3><p className="text-sm text-gray-400 text-left md:text-center">We help you until your final submission is complete.</p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <Stats />
            <TestimonialCarousel />
            
            <section className="gradient-bg-section">
                <div className="container mx-auto px-6 py-20 text-center animate-on-scroll">
                    <h2 className="text-4xl md:text-5xl font-black text-white mb-4 hero-title-shadow">Ready to Start Building?</h2>
                    <p className="text-violet-200 max-w-2xl mx-auto mb-8">Don't let project deadlines stress you out. Reach out to us today and let's build something amazing together!</p>
                    <div className="flex justify-center items-center flex-wrap gap-4">
                        <a href="https://forms.gle/u3VxhUY4fofGzPiV8" target="_blank" rel="noopener noreferrer" className="bg-white text-violet-700 font-bold px-8 py-4 rounded-lg text-lg transform hover:scale-105 transition-transform duration-300 glow-effect">Get Your Kit</a>
                        <a href="https://www.instagram.com/project_buddyy_11" target="_blank" rel="noopener noreferrer" className="bg-pink-600 text-white font-bold px-8 py-4 rounded-lg text-lg transform hover:scale-105 transition-transform duration-300 flex items-center gap-2 glow-effect"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>Message on Instagram</a>
                        <a href="https://wa.me/919373286008" target="_blank" rel="noopener noreferrer" className="bg-green-500 text-white font-bold px-8 py-4 rounded-lg text-lg transform hover:scale-105 transition-transform duration-300 flex items-center gap-2 glow-effect">
                           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
                           Chat on WhatsApp
                        </a>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default HomePage;