import React from 'react';
import useScrollAnimation from '../hooks/useScrollAnimation';

const AboutPage: React.FC = () => {
    useScrollAnimation();

    return (
        <section className="relative py-20 bg-about bg-cover-center">
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"></div>
            <div className="container mx-auto px-6 relative z-10">
                <div className="text-center mb-16 animate-on-scroll">
                    <h2 className="text-4xl md:text-5xl font-black text-white">About <span className="gradient-text">Us</span></h2>
                </div>
                <div className="relative max-w-3xl mx-auto text-center animate-on-scroll" style={{ transitionDelay: '100ms' }}>
                    <svg className="absolute -top-16 -right-16 h-48 w-48 text-white/5 opacity-50 -z-10" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.438.995s.145.755.438.995l1.003.827c.481.398.668 1.03.26 1.431l-1.296 2.247a1.125 1.125 0 01-1.37.49l-1.217-.456c-.355-.133-.75-.072-1.075.124a6.57 6.57 0 01-.22.127c-.332.183-.582.495-.645.87l-.213 1.281c-.09.542-.56.94-1.11-.94h-2.593c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.063-.374-.313.686-.645-.87a6.52 6.52 0 01-.22-.127c-.324-.196-.72-.257-1.075-.124l-1.217.456a1.125 1.125 0 01-1.37-.49l-1.296-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.437-.995s-.145-.755-.437-.995l-1.004-.827a1.125 1.125 0 01-.26-1.431l1.296-2.247a1.125 1.125 0 011.37-.49l1.217.456c.355.133.75.072 1.075-.124.072-.044.146-.087.22-.127.332-.183.582.495.645-.87l.213-1.281z" />
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
                        ProjectBuddy is a student-led startup helping engineering students learn by building. We provide DIY kits, rental options, and one-on-one mentor guidance until you successfully complete your project.
                    </p>
                </div>
            </div>
        </section>
    );
};

export default AboutPage;